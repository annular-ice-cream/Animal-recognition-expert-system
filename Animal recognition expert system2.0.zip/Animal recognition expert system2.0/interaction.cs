﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal_recognition_expert_system
{
    public partial class interaction : Form
    {
        enum Features//枚举类型Features定义了初始各种动物特征
        {
            有毛发,
            有羽毛,
            会飞,
            会下蛋,
            吃肉,
            有犀利牙齿,
            有爪,
            眼盯前方,
            有蹄,
            嚼反刍,
            黄褐色,
            身上有暗斑点,
            身上有黑色条纹,
            有长脖子,
            有长腿,
            不会飞,
            会游泳,
            有黑白二色,
            善飞
        }

        List<(List<Features>, string)> rules = new List<(List<Features>, string)>();//规则，其中的每个元素都是一个元组
        List<string> factsList = new List<string>(); // 存储事实的列表

        public interaction()
        {
            InitializeComponent();
            //初始化规则清空rules
            rules.Clear();
            //注释掉初始化规则列表，或者在加载规则文件后判断是否需要初始化
            //InitializeRules();
            LoadFactsFromFile();
            LoadRulesFromFile();
            PopulateFactListBox();
            PopulateRuleListBox();
            
        }

        private void LoadFactsFromFile()//加载事实文件，从facts.txt中加载事实，存储到factsList列表中
        {
            if (File.Exists("facts.txt"))
            {
                string[] lines = File.ReadAllLines("facts.txt");
                foreach (var line in lines)
                {
                    factsList.Add(line);
                }
            }
        }

        private void SaveFactsToFile()//保存事实到文件
        {
            File.WriteAllLines("facts.txt", factsList);
        }

        //初始化规则列表,规则 “如果动物有毛发，则是哺乳动物” 被表示为(new List<Features> { Features.有毛发 }, "哺乳动物")
        private void InitializeRules()
        {
            rules.Add((new List<Features> { Features.有毛发 }, "哺乳动物"));
            rules.Add((new List<Features> { Features.有羽毛 }, "鸟"));
            rules.Add((new List<Features> { Features.会飞, Features.会下蛋 }, "鸟"));
            rules.Add((new List<Features> { Features.吃肉 }, "食肉动物"));
            rules.Add((new List<Features> { Features.有犀利牙齿, Features.有爪, Features.眼盯前方 }, "食肉动物"));
            rules.Add((GetFeaturesFromCategory("哺乳动物").Concat(new List<Features> { Features.有蹄 }).ToList(), "有蹄类动物"));
            rules.Add((GetFeaturesFromCategory("哺乳动物").Concat(new List<Features> { Features.嚼反刍 }).ToList(), "有蹄类动物"));
            rules.Add((GetFeaturesFromCategory("哺乳动物").Concat(GetFeaturesFromCategory("食肉动物")).Concat(new List<Features> { Features.黄褐色, Features.身上有暗斑点 }).ToList(), "豹"));
            rules.Add((GetFeaturesFromCategory("哺乳动物").Concat(GetFeaturesFromCategory("食肉动物")).Concat(new List<Features> { Features.黄褐色, Features.身上有黑色条纹 }).ToList(), "虎"));
            rules.Add((GetFeaturesFromCategory("有蹄类动物").Concat(new List<Features> { Features.有长脖子, Features.有长腿, Features.身上有暗斑点 }).ToList(), "长颈鹿"));
            rules.Add((GetFeaturesFromCategory("有蹄类动物").Concat(new List<Features> { Features.身上有黑色条纹 }).ToList(), "斑马"));
            rules.Add((new List<Features> { Features.有羽毛 }.Concat(new List<Features> { Features.不会飞, Features.有长脖子, Features.有长腿, Features.有黑白二色 }).ToList(), "鸵鸟"));
            rules.Add((new List<Features> { Features.有羽毛 }.Concat(new List<Features> { Features.不会飞, Features.会游泳, Features.有黑白二色 }).ToList(), "企鹅"));
            rules.Add((new List<Features> { Features.有羽毛 }.Concat(new List<Features> { Features.善飞, Features.会下蛋 }).ToList(), "信天翁"));
        }

        //辅助，动物->特征
        List<Features> GetFeaturesFromCategory(string category)
        {
            switch (category)
            {
                case "哺乳动物":
                    return new List<Features> { Features.有毛发 };
                case "食肉动物":
                    return new List<Features> { Features.吃肉, Features.有犀利牙齿, Features.有爪, Features.眼盯前方 };
                case "有蹄类动物":
                    return new List<Features> { Features.有蹄, Features.嚼反刍 };
                case "豹":
                    return new List<Features> { Features.有毛发, Features.吃肉, Features.有犀利牙齿, Features.有爪, Features.眼盯前方, Features.黄褐色, Features.身上有暗斑点 };
                case "虎":
                    return new List<Features> { Features.有毛发, Features.吃肉, Features.有犀利牙齿, Features.有爪, Features.眼盯前方, Features.黄褐色, Features.身上有黑色条纹 };
                case "长颈鹿":
                    return new List<Features> { Features.有蹄, Features.嚼反刍, Features.有长脖子, Features.有长腿, Features.身上有暗斑点 };
                case "斑马":
                    return new List<Features> { Features.有蹄, Features.嚼反刍, Features.身上有黑色条纹 };
                case "鸵鸟":
                    return new List<Features> { Features.有羽毛, Features.不会飞, Features.有长脖子, Features.有长腿, Features.有黑白二色 };
                case "企鹅":
                    return new List<Features> { Features.有羽毛, Features.不会飞, Features.会游泳, Features.有黑白二色 };
                case "信天翁":
                    return new List<Features> { Features.有羽毛, Features.善飞, Features.会下蛋 };
                case "鸟":
                    return new List<Features> { Features.会飞, Features.会下蛋 };
                default:
                    return new List<Features>();
            }

        }

        private void PopulateFactListBox()//显示到事实框（动物特征）
        {
            showfacts.Items.Clear();
            foreach (Features feature in Enum.GetValues(typeof(Features)))//枚举类型Features动物特征的所有值
            {
                showfacts.Items.Add(feature.ToString());
            }
            foreach (var fact in factsList)//文件中的已有事实
            {
                showfacts.Items.Add(fact);
            }
        }

        private void PopulateRuleListBox()//初始化的规则、规则文件中的规则显示到规则集
        {
            showrules.Items.Clear();//清空，保证每次填充时都是最新的状态
            foreach (var rule in rules)//遍历存储规则的列表rules，
            {
                string ruleText = string.Join(", ", rule.Item1.Select(f => f.ToString())) + " -> " + rule.Item2;//将规则中的特征列表（rule.Item1）中的每个特征转换为字符串并以逗号分隔连接起来。然后加上 " -> " 和规则的结果部分（rule.Item2），表示从特征到结果的推理关系。
                showrules.Items.Add(ruleText); //将构建好的规则文本添加到列表框中进行展示
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void interaction_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)//退出系统
        {
            Application.Exit();
        }

        private void selectfacts_Click(object sender, EventArgs e)//选择事实按钮
        {
            if (showfacts.SelectedItem != null)
            {
                showselectfacts.Items.Add(showfacts.SelectedItem);
            }
        }

        private void deletefacts_Click(object sender, EventArgs e)//删除事实按钮
        {
            if (showselectfacts.SelectedItem != null)
            {
                showselectfacts.Items.Remove(showselectfacts.SelectedItem);
            }
        }

        private void addfact_Click(object sender, EventArgs e)
        {

        }

        
        private void addrule_Click(object sender, EventArgs e)//添加新规则
        {
            add_rule addRuleForm = new add_rule();
            if (addRuleForm.ShowDialog() == DialogResult.OK)//点击确定
            {
                string newRule = addRuleForm.NewRule;//从addRuleForm窗体中获取用户输入的新规则，并将其存储在newRule字符串变量中
                if (!string.IsNullOrWhiteSpace(newRule))//如果不为空
                {
                    //将newRule按照 “->” 进行分割。分割后的结果存储在parts数组中
                    string[] parts = newRule.Split(new string[] { "->" }, StringSplitOptions.None);
                    if (parts.Length == 2)//正好分割成两部分
                    {
                        //提取特征部分（分割后的第一个元素），去除两端的空白字符，然后再按照逗号进行分割，得到一个特征名称的数组
                        string[] featureNames = parts[0].Trim().Split(',');
                        //创建一个名为features的列表，用于存储解析后的特征枚举值。
                        List<Features> features = new List<Features>();
                        //遍历特征名称数组中的每个特征名称
                        foreach (string featureName in featureNames)
                        {
                            //尝试将每个特征名称解析为枚举类型Features。如果解析成功，将解析后的枚举值添加到features列表中。
                            if (Enum.TryParse(featureName.Trim(), out Features feature))
                            {
                                features.Add(feature);
                            }
                        }
                        //提取结果部分（分割后的第二个元素），去除两端的空白字符，得到规则的结果部分。
                        string result = parts[1].Trim();
                        //将解析后的特征列表和结果添加到rules列表中。rules列表的类型是List<(List<Features>, string)>，即包含一个特征列表和一个字符串结果的元组列表。
                        rules.Add((features, result));
                        //将用户输入的完整新规则添加到showrules列表框中，以便在用户界面上显示新添加的规则。
                        showrules.Items.Add(newRule);

                        // 保存新规则到文件
                        SaveRulesToFile();
                        PopulateRuleListBox(); // 添加这行，确保添加规则后更新列表框显示
                    }
                }
            }
        }

        private void LoadRulesFromFile()//从文件 “rules.txt” 中加载规则，并将其存储到rules列表中
        {
            if (File.Exists("rules.txt"))//存在
            {
                string[] lines = File.ReadAllLines("rules.txt");
                foreach (var line in lines)
                {
                    string[] parts = line.Split(new string[] { "->" }, StringSplitOptions.None);//以 “->” 为分隔符将其分割为两部分。
                    if (parts.Length == 2)//如果分割后得到的部分数量不等于 2，则跳过当前代码块。
                    {
                        string[] featureNames = parts[0].Trim().Split(',');//将特征部分去除两端空白并以逗号分割，得到特征名称数组。
                        List<Features> convertedFeatures = new List<Features>();
                        foreach (string featureName in featureNames)
                        {
                            if (Enum.TryParse(featureName.Trim(), out Features feature))//将每个特征名称解析为枚举类型Features，如果解析成功则添加到convertedFeatures列表中
                            {
                                convertedFeatures.Add(feature);
                            }
                        }
                        string result = parts[1].Trim();//将结果部分去除两端空白，得到规则的结果（动物）字符串。
                        rules.Add((convertedFeatures, result));//将处理后的特征列表和结果添加到rules列表中：
                    }
                }
                PopulateRuleListBox(); // 添加这行，确保加载规则后更新列表框显示
            }
        }

        public void SaveRulesToFile()//将当前系统中的规则保存到文件 “rules.txt” 中
        {

            // 先清空文件
            File.WriteAllText("rules.txt", string.Empty);
            List<string> ruleLines = new List<string>();
            foreach (var rule in rules)//遍历当前系统中的规则列表rules
            {
                string ruleText = string.Join(", ", rule.Item1) + " -> " + rule.Item2;//将规则的特征列表（rule.Item1）中的特征以逗号分隔连接起来，再加上 “->” 和规则的结果部分（rule.Item2），构建成一个字符串表示的规则。
                ruleLines.Add(ruleText);//将构建好的规则字符串添加到ruleLines列表中
            }
            File.WriteAllLines("rules.txt", ruleLines);//列表中的所有字符串写入文件 “rules.txt”
        }

        private void addfact_Click_1(object sender, EventArgs e)//处理添加新事实
        {
            add_fact  addFactForm = new add_fact();
            if (addFactForm.ShowDialog() == DialogResult.OK)
            {
                string newFact = addFactForm.NewFact;
                if (!string.IsNullOrWhiteSpace(newFact))//检查新事实是否为空或只包含空白字符
                {
                    factsList.Add(newFact);//新事实添加到factsList列表
                    showfacts.Items.Add(newFact);//将新事实添加到事实列表框showfacts中
                    SaveFactsToFile();//保存事实到文件的方法，将新添加的事实保存到文件中
                }
            }
        }

        private void update_Click(object sender, EventArgs e)//点击刷新按钮
        {
            showselectfacts.Items.Clear();
            result.Items.Clear();
            Reasoning_process.Items.Clear();
        }

        private void beginwork_Click(object sender, EventArgs e)//开始推理按钮
        {
            // 清空结果和推理过程列表框
            result.Items.Clear();
            Reasoning_process.Items.Clear();

            // 获取选中的事实列表
            List<string> selectedFacts = new List<string>();
            foreach (var item in showselectfacts.Items)
            {
                selectedFacts.Add(item.ToString());
            }
            
            // 推理过程
            List<string> possibleAnimals = new List<string>();//possibleAnimals用于存储可能的动物种类
            foreach (var rule in rules)
            {
                bool allFeaturesPresent = true;
                foreach (var feature in rule.Item1)//遍历规则列表rules中的每一个规则。对于每个规则，特征是否都在选中的事实列表中。如果是，则表示该规则可能适用。
                {
                    if (!selectedFacts.Contains(feature.ToString()))
                    {
                        allFeaturesPresent = false;
                        break;
                    }
                }
                if (allFeaturesPresent)//如果规则适用，将规则的结果动物种类添加到possibleAnimals列表中
                {
                    string resultAnimal = rule.Item2;
                    if (!possibleAnimals.Contains(resultAnimal))
                    {
                        possibleAnimals.Add(resultAnimal);
                        Reasoning_process.Items.Add($"应用规则：{string.Join(", ", rule.Item1)} -> {resultAnimal}");//在推理过程列表框中添加相应的推理记录。
                    }
                }
            }
            
            // 遍历所有规则，对可能的结果进行更全面的判断
            foreach (var rule in rules) //再次遍历规则列表，但这次排除了一些基础的动物类别,仅考虑那些结果不是基础类别的规则,体现优先级
            {
                if (rule.Item2 != "哺乳动物" && rule.Item2 != "食肉动物" && rule.Item2 != "有蹄类动物" && rule.Item2 != "鸟")
                {
                    bool allFeaturesPresent = true;
                    foreach (var feature in rule.Item1)
                    {
                        if (!selectedFacts.Contains(feature.ToString()))
                        {
                            allFeaturesPresent = false;
                            break;
                        }
                    }
                    if (allFeaturesPresent)
                    {
                        possibleAnimals.Add(rule.Item2);
                    }
                }
            }

            // 将可能的动物添加到结果列表框
            foreach (var animal in possibleAnimals)
            {
                result.Items.Add(animal);
            }
        }

        private void deleterule_Click(object sender, EventArgs e)//删除规则按钮
        {
            if (showrules.SelectedItem != null)
            {
                string selectedRuleText = showrules.SelectedItem.ToString();
                string[] parts = selectedRuleText.Split(new string[] { "->" }, StringSplitOptions.None);//以 “->” 为分隔符将选中规则的文本分割为两部分，分别对应特征列表和结果部分。
                string[] featureNames = parts[0].Trim().Split(',');//提取特征列表部分，去除两端空白并以逗号分割，得到特征名称数组。
                List<Features> features = new List<Features>();
                foreach (string featureName in featureNames)//将每个特征名称解析为枚举类型Features，并添加到features列表中。
                {
                    if (Enum.TryParse(featureName.Trim(), out Features feature))
                    {
                        features.Add(feature);
                    }
                }
                string result = parts[1].Trim();//提取结果部分，去除两端空白，得到规则的结果字符串
                var ruleToRemove = rules.FirstOrDefault(r => Enumerable.SequenceEqual(r.Item1, features) && r.Item2 == result); //在规则列表rules中查找与选中规则具有相同特征列表和结果的规则
                if (ruleToRemove != default((List<Features>, string)))//如果找到要删除的规则就删除
                {
                    rules.Remove(ruleToRemove);
                    SaveRulesToFile();//将更新后的规则列表保存到文件中。
                    PopulateRuleListBox();//重新填充规则集列表框，以显示更新后的规则列表。
                }
            }
        }
    }
}
