﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animal_recognition_expert_system
{
    public partial class add_fact : Form
    {
        public string NewFact { get; private set; }
        public add_fact()
        {
            InitializeComponent();
        }

        private void add_fact_Load(object sender, EventArgs e)
        {

        }

        private void yes_Click(object sender, EventArgs e)
        {
            NewFact = inputnewfact.Text;
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void no_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
