﻿namespace Animal_recognition_expert_system
{
    partial class interaction
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.selectfacts = new System.Windows.Forms.Button();
            this.deletefacts = new System.Windows.Forms.Button();
            this.update = new System.Windows.Forms.Button();
            this.addfact = new System.Windows.Forms.Button();
            this.addrule = new System.Windows.Forms.Button();
            this.beginwork = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.showfacts = new System.Windows.Forms.ListBox();
            this.showselectfacts = new System.Windows.Forms.ListBox();
            this.showrules = new System.Windows.Forms.ListBox();
            this.Reasoning_process = new System.Windows.Forms.ListBox();
            this.result = new System.Windows.Forms.ListBox();
            this.deleterule = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("幼圆", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(539, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(261, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "动物识别专家系统";
            // 
            // selectfacts
            // 
            this.selectfacts.BackColor = System.Drawing.Color.PaleGreen;
            this.selectfacts.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.selectfacts.Location = new System.Drawing.Point(68, 715);
            this.selectfacts.Name = "selectfacts";
            this.selectfacts.Size = new System.Drawing.Size(168, 40);
            this.selectfacts.TabIndex = 4;
            this.selectfacts.Text = "选择事实";
            this.selectfacts.UseVisualStyleBackColor = false;
            this.selectfacts.Click += new System.EventHandler(this.selectfacts_Click);
            // 
            // deletefacts
            // 
            this.deletefacts.BackColor = System.Drawing.Color.PaleGreen;
            this.deletefacts.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deletefacts.Location = new System.Drawing.Point(296, 715);
            this.deletefacts.Name = "deletefacts";
            this.deletefacts.Size = new System.Drawing.Size(168, 40);
            this.deletefacts.TabIndex = 5;
            this.deletefacts.Text = "删除选中事实";
            this.deletefacts.UseVisualStyleBackColor = false;
            this.deletefacts.Click += new System.EventHandler(this.deletefacts_Click);
            // 
            // update
            // 
            this.update.BackColor = System.Drawing.Color.PaleGreen;
            this.update.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.update.Location = new System.Drawing.Point(68, 782);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(168, 40);
            this.update.TabIndex = 6;
            this.update.Text = "刷新";
            this.update.UseVisualStyleBackColor = false;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // addfact
            // 
            this.addfact.BackColor = System.Drawing.Color.PaleGreen;
            this.addfact.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addfact.Location = new System.Drawing.Point(68, 562);
            this.addfact.Name = "addfact";
            this.addfact.Size = new System.Drawing.Size(168, 40);
            this.addfact.TabIndex = 7;
            this.addfact.Text = "添加新事实";
            this.addfact.UseVisualStyleBackColor = false;
            this.addfact.Click += new System.EventHandler(this.addfact_Click_1);
            // 
            // addrule
            // 
            this.addrule.BackColor = System.Drawing.Color.PaleGreen;
            this.addrule.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.addrule.Location = new System.Drawing.Point(296, 562);
            this.addrule.Name = "addrule";
            this.addrule.Size = new System.Drawing.Size(168, 40);
            this.addrule.TabIndex = 8;
            this.addrule.Text = "添加新规则";
            this.addrule.UseVisualStyleBackColor = false;
            this.addrule.Click += new System.EventHandler(this.addrule_Click);
            // 
            // beginwork
            // 
            this.beginwork.BackColor = System.Drawing.Color.PaleGreen;
            this.beginwork.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.beginwork.Location = new System.Drawing.Point(296, 777);
            this.beginwork.Name = "beginwork";
            this.beginwork.Size = new System.Drawing.Size(168, 40);
            this.beginwork.TabIndex = 9;
            this.beginwork.Text = "开始推理";
            this.beginwork.UseVisualStyleBackColor = false;
            this.beginwork.Click += new System.EventHandler(this.beginwork_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Cyan;
            this.button7.Location = new System.Drawing.Point(1285, 19);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(74, 40);
            this.button7.TabIndex = 10;
            this.button7.Text = "退出";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(49, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 24);
            this.label2.TabIndex = 11;
            this.label2.Text = "事实";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(359, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 24);
            this.label3.TabIndex = 12;
            this.label3.Text = "已选中事实";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(926, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 24);
            this.label4.TabIndex = 13;
            this.label4.Text = "规则集";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(540, 539);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 24);
            this.label5.TabIndex = 14;
            this.label5.Text = "推理过程";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.Location = new System.Drawing.Point(540, 782);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 24);
            this.label6.TabIndex = 15;
            this.label6.Text = "推理结果";
            // 
            // showfacts
            // 
            this.showfacts.BackColor = System.Drawing.Color.Turquoise;
            this.showfacts.FormattingEnabled = true;
            this.showfacts.ItemHeight = 18;
            this.showfacts.Location = new System.Drawing.Point(41, 97);
            this.showfacts.Name = "showfacts";
            this.showfacts.Size = new System.Drawing.Size(264, 382);
            this.showfacts.TabIndex = 16;
            this.showfacts.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // showselectfacts
            // 
            this.showselectfacts.BackColor = System.Drawing.Color.Turquoise;
            this.showselectfacts.FormattingEnabled = true;
            this.showselectfacts.ItemHeight = 18;
            this.showselectfacts.Location = new System.Drawing.Point(349, 97);
            this.showselectfacts.Name = "showselectfacts";
            this.showselectfacts.Size = new System.Drawing.Size(264, 382);
            this.showselectfacts.TabIndex = 17;
            // 
            // showrules
            // 
            this.showrules.BackColor = System.Drawing.Color.Turquoise;
            this.showrules.FormattingEnabled = true;
            this.showrules.ItemHeight = 18;
            this.showrules.Location = new System.Drawing.Point(669, 97);
            this.showrules.Name = "showrules";
            this.showrules.Size = new System.Drawing.Size(670, 382);
            this.showrules.TabIndex = 18;
            // 
            // Reasoning_process
            // 
            this.Reasoning_process.BackColor = System.Drawing.Color.Turquoise;
            this.Reasoning_process.FormattingEnabled = true;
            this.Reasoning_process.ItemHeight = 18;
            this.Reasoning_process.Location = new System.Drawing.Point(669, 520);
            this.Reasoning_process.Name = "Reasoning_process";
            this.Reasoning_process.Size = new System.Drawing.Size(670, 184);
            this.Reasoning_process.TabIndex = 19;
            // 
            // result
            // 
            this.result.BackColor = System.Drawing.Color.Turquoise;
            this.result.FormattingEnabled = true;
            this.result.ItemHeight = 18;
            this.result.Location = new System.Drawing.Point(669, 765);
            this.result.Name = "result";
            this.result.Size = new System.Drawing.Size(670, 76);
            this.result.TabIndex = 20;
            // 
            // deleterule
            // 
            this.deleterule.BackColor = System.Drawing.Color.PaleGreen;
            this.deleterule.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deleterule.Location = new System.Drawing.Point(179, 636);
            this.deleterule.Name = "deleterule";
            this.deleterule.Size = new System.Drawing.Size(168, 40);
            this.deleterule.TabIndex = 21;
            this.deleterule.Text = "删除规则";
            this.deleterule.UseVisualStyleBackColor = false;
            this.deleterule.Click += new System.EventHandler(this.deleterule_Click);
            // 
            // interaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(1388, 906);
            this.Controls.Add(this.deleterule);
            this.Controls.Add(this.result);
            this.Controls.Add(this.Reasoning_process);
            this.Controls.Add(this.showrules);
            this.Controls.Add(this.showselectfacts);
            this.Controls.Add(this.showfacts);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.beginwork);
            this.Controls.Add(this.addrule);
            this.Controls.Add(this.addfact);
            this.Controls.Add(this.update);
            this.Controls.Add(this.deletefacts);
            this.Controls.Add(this.selectfacts);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "interaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.interaction_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button selectfacts;
        private System.Windows.Forms.Button deletefacts;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button addfact;
        private System.Windows.Forms.Button addrule;
        private System.Windows.Forms.Button beginwork;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox showfacts;
        private System.Windows.Forms.ListBox showselectfacts;
        private System.Windows.Forms.ListBox showrules;
        private System.Windows.Forms.ListBox Reasoning_process;
        private System.Windows.Forms.ListBox result;
        private System.Windows.Forms.Button deleterule;
    }
}

